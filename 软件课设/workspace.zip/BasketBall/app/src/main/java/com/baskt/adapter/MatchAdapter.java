package com.baskt.adapter;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.baskt.ui.AddMatchAnalysisActivity;
import com.baskt.ui.AnalysisMatchActivity;
import com.baskt.ui.CollectDataMatchActivity;
import com.baskt.ui.EditMatchActivity;
import com.bumptech.glide.Glide;
import com.baskt.R;
import com.baskt.model.Match;
import com.baskt.utils.GlobalFunction;
import com.baskt.utils.GlobalVariables;
import com.baskt.widgets.RoundImageView;

import java.util.List;

public class MatchAdapter extends RecyclerView.Adapter<MatchAdapter.MyViewHolder> {
    private Context context;
    private LayoutInflater mInflater;
    private List<Match> items;

    // 图片数组
    public MatchAdapter(Context context, List<Match> items) {
        this.context = context;
        mInflater = LayoutInflater.from(context);
        this.items = items;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        MyViewHolder viewHolder = new MyViewHolder(LayoutInflater.from(context).inflate(R.layout.match_item, parent, false));
        return viewHolder;
    }

    // 创建View方法
    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        final int pos = position;
        Match item = items.get(pos);
        holder.tvName.setText("主题:"+item.getName());
        holder.tvContent.setText("对阵双方:"+item.getName1()+"VS"+item.getName2());
        holder.tvResult.setText("比赛结果:"+item.getScore1()+"/"+item.getScore2());
        holder.tvTime.setText("比赛时间:"+GlobalFunction.formatDate(item.getCreateTime()));

    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder {
        private TextView tvName;
        private TextView tvContent;
        private TextView tvResult;
        private TextView tvTime;
        private TextView tvCollect;
        private TextView tvEdit;
        private TextView tvAnaly;
        private RoundImageView avatar;
        private int pos;

        public int getPos() {
            return pos;
        }

        public void setPos(int pos) {
            this.pos = pos;
        }

        public MyViewHolder(View convertView) {
            super(convertView);
            tvName = (TextView) convertView.findViewById(R.id.tv_name);
            tvContent = (TextView) convertView.findViewById(R.id.tv_content);
            tvResult = (TextView) convertView.findViewById(R.id.tv_result);
            tvTime = (TextView) convertView.findViewById(R.id.tv_time);
            tvEdit = (TextView) convertView.findViewById(R.id.tv_edit);
            tvCollect = (TextView) convertView.findViewById(R.id.tv_collect);
            tvAnaly = (TextView) convertView.findViewById(R.id.tv_analy);
            avatar = (RoundImageView) convertView.findViewById(R.id.avatar);
            tvEdit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Match item = items.get(pos);
                    Intent intent = new Intent(context, EditMatchActivity.class);
                    intent.putExtra("item",item);
                    context.startActivity(intent);
                }
            });
            tvCollect.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Match item = items.get(pos);
                    Intent intent = new Intent(context, CollectDataMatchActivity.class);
                    intent.putExtra("item",item);
                    context.startActivity(intent);
                }
            });
            tvAnaly.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Match item = items.get(pos);
                    Intent intent = new Intent(context, AddMatchAnalysisActivity.class);
                    intent.putExtra("item",item);
                    context.startActivity(intent);
                }
            });
        }
    }


}
