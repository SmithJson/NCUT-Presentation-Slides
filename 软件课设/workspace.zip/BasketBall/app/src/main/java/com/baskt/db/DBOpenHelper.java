package com.baskt.db;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.baskt.model.Match;
import com.baskt.model.Record;
import com.baskt.model.Tail;
import com.j256.ormlite.android.apptools.OrmLiteSqliteOpenHelper;
import com.j256.ormlite.support.ConnectionSource;
import com.j256.ormlite.table.TableUtils;
import com.baskt.model.Member;

public class DBOpenHelper extends OrmLiteSqliteOpenHelper {
	public static String dbPath;
	public static final int DB_VERSION = 2;
	public DBOpenHelper(Context context) {
		super(context, "task.db", null, DB_VERSION);
	}

	@Override
	public void onCreate(SQLiteDatabase sqLiteDatabase,
			ConnectionSource connectionSource) {
		try {
			TableUtils.createTableIfNotExists(connectionSource, Member.class);
			TableUtils.createTableIfNotExists(connectionSource, Match.class);
			TableUtils.createTableIfNotExists(connectionSource, Record.class);
			TableUtils.createTableIfNotExists(connectionSource, Tail.class);
			sqLiteDatabase.setVersion(DB_VERSION);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// dao.executeRaw("ALTER TABLE `account` ADD COLUMN hasDog BOOLEAN DEFAULT 0;");
	// dao.updateRaw("UPDATE `account` SET hasDog = 1 WHERE dogCount > 0;");
	@Override
	public void onUpgrade(SQLiteDatabase sqLiteDatabase,
                          ConnectionSource connectionSource, int oldVersion, int newVersion) {
		try {
//			update7Version(connectionSource,oldVersion);
//			update8Version(sqLiteDatabase, oldVersion);
			sqLiteDatabase.setVersion(newVersion);
		} catch (Exception e) {
			e.printStackTrace();
			System.out
					.println("================================================情爱的孩子，抛了异常");
		}
	}
	
//	private void update8Version(SQLiteDatabase sqLiteDatabase,int oldVersion) throws SQLException {
//		if(oldVersion < DB_VERSION){
//			if (!checkColumnExist(sqLiteDatabase, "role", "read")) {
//				Dao<Role, String> childOne = getDao(Role.class);
//				childOne.executeRaw("ALTER TABLE 'role' ADD COLUMN read varchar;");
//			}
//		}
//	}

	/*private void update7Version(ConnectionSource connectionSource,int oldVersion) {
		if (oldVersion < 7) {
			try {
				TableUtils
						.dropTable(connectionSource, IMMessage.class,true);
				TableUtils
						.dropTable(connectionSource, IMSession.class,true);
				TableUtils.dropTable(connectionSource, Role.class,true);
			} catch (Exception e) {
				// TODO Auto-generated catch block
			}
			try {
				TableUtils
						.createTableIfNotExists(connectionSource, IMMessage.class);
				TableUtils
						.createTableIfNotExists(connectionSource, IMSession.class);
				TableUtils.createTableIfNotExists(connectionSource, Role.class);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
*/
	private boolean checkColumnExist(SQLiteDatabase db, String tableName,
                                     String columnName) {
		boolean result = false;
		Cursor cursor = null;
		try {
			cursor = db.rawQuery("SELECT * FROM " + tableName + " LIMIT 0",
					null);
			result = cursor != null && cursor.getColumnIndex(columnName) != -1;
		} catch (Exception e) {
		} finally {
			if (null != cursor && !cursor.isClosed()) {
				cursor.close();
			}
		}
		return result;
	}

	@Override
	public void close() {
		super.close();
	}
}
