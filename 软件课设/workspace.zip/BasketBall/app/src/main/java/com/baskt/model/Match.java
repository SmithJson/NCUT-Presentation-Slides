package com.baskt.model;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;
import com.richard.tool.model.BaseModel;

@DatabaseTable(tableName = "t_match")
public class Match extends BaseModel {
    @DatabaseField
    private String name;//比赛名称
    @DatabaseField
    private String name1;//球队1名称
    @DatabaseField
    private String name2;//球队2名称
    @DatabaseField
    private int score1;//球队1得分
    @DatabaseField
    private int score2;//球队2得分
    @DatabaseField
    private int difficulty;//技术难度
    @DatabaseField
    private int completation;//技术完成度
    @DatabaseField
    private int effect;//技术有效性
    @DatabaseField
    private int ratio;//战术克制程度
    @DatabaseField
    private int comp;//战术完成程度
    @DatabaseField
    private int wrong;//失误
    @DatabaseField
    private long createTime;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName1() {
        return name1;
    }

    public void setName1(String name1) {
        this.name1 = name1;
    }

    public String getName2() {
        return name2;
    }

    public void setName2(String name2) {
        this.name2 = name2;
    }

    public int getScore1() {
        return score1;
    }

    public void setScore1(int score1) {
        this.score1 = score1;
    }

    public int getScore2() {
        return score2;
    }

    public void setScore2(int score2) {
        this.score2 = score2;
    }

    public int getDifficulty() {
        return difficulty;
    }

    public void setDifficulty(int difficulty) {
        this.difficulty = difficulty;
    }

    public int getCompletation() {
        return completation;
    }

    public void setCompletation(int completation) {
        this.completation = completation;
    }

    public int getEffect() {
        return effect;
    }

    public void setEffect(int effect) {
        this.effect = effect;
    }

    public int getRatio() {
        return ratio;
    }

    public void setRatio(int ratio) {
        this.ratio = ratio;
    }

    public int getComp() {
        return comp;
    }

    public void setComp(int comp) {
        this.comp = comp;
    }

    public int getWrong() {
        return wrong;
    }

    public void setWrong(int wrong) {
        this.wrong = wrong;
    }

    public long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(long createTime) {
        this.createTime = createTime;
    }
}
