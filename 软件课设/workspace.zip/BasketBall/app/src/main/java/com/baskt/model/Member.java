package com.baskt.model;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;
import com.richard.tool.model.BaseModel;

/**
 * 用户对象
 */
@DatabaseTable(tableName = "t_member")
public class Member extends BaseModel {
    @DatabaseField
    private String name;
    @DatabaseField
    private String mobile;
    @DatabaseField
    private String avatar;
    @DatabaseField
    private String pwd;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }
}

