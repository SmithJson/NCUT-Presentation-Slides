package com.baskt.model;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;
import com.richard.tool.model.BaseModel;

/**
 * 记录
 */
@DatabaseTable(tableName = "t_record")
public class Record extends BaseModel {
    @DatabaseField
    private int mid;//比赛id
    @DatabaseField
    private String name;//运动员
    @DatabaseField
    private int distance;
    @DatabaseField
    private int speed;
    @DatabaseField
    private long createTime;

    public int getMid() {
        return mid;
    }

    public void setMid(int mid) {
        this.mid = mid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getDistance() {
        return distance;
    }

    public void setDistance(int distance) {
        this.distance = distance;
    }

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    public long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(long createTime) {
        this.createTime = createTime;
    }
}

