package com.baskt.model;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;
import com.richard.tool.model.BaseModel;

/**
 * 轨迹
 */
@DatabaseTable(tableName = "t_tail")
public class Tail extends BaseModel {
    @DatabaseField
    private int mid;//比赛id
    @DatabaseField
    private String name;//运动员
    @DatabaseField
    private int x;
    @DatabaseField
    private int y;
    @DatabaseField
    private long createTime;

    public int getMid() {
        return mid;
    }

    public void setMid(int mid) {
        this.mid = mid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(long createTime) {
        this.createTime = createTime;
    }
}

