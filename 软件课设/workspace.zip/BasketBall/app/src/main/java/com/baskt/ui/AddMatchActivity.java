package com.baskt.ui;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.baskt.R;
import com.baskt.db.DBOpenHelper;
import com.baskt.model.Match;
import com.baskt.ui.base.ManageActivity;
import com.baskt.utils.GlobalFunction;
import com.baskt.utils.ScreenManager;
import com.hb.dialog.dialog.LoadingDialog;
import com.richard.tool.database.BaseModelManager;
import com.shehuan.niv.NiceImageView;

import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

@ContentView(R.layout.activity_add_match)
public class AddMatchActivity extends ManageActivity {
    @ViewInject(R.id.iv_back)
    public ImageView back;
    @ViewInject(R.id.et_name)
    public EditText etName;
    @ViewInject(R.id.et_name1)
    public EditText etName1;
    @ViewInject(R.id.et_name2)
    public EditText etName2;
    @ViewInject(R.id.et_score1)
    public EditText etScore1;
    @ViewInject(R.id.et_score2)
    public EditText etScore2;
    @ViewInject(R.id.tv_ok)
    public TextView tvOk;
    private LoadingDialog loadingDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        x.view().inject(this);
        initView();
    }

    @Override
    protected void initView() {
        super.initView();
        tvOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                add();
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ScreenManager.getScreenManager().popActivity();
            }
        });
    }

    Handler handler = new Handler() {
        public void handleMessage(Message msg) {
            if (loadingDialog != null) {
                loadingDialog.dismiss();
            }
            switch (msg.what) {
                case 0:
                    GlobalFunction.showToast(AddMatchActivity.this, "添加成功。");
                    ScreenManager.getScreenManager().popActivity();
                    break;
                case 1:
                    GlobalFunction.showToast(AddMatchActivity.this, "添加失败");
                    break;
                default:
                    break;
            }
        }
    };

    private void add() {
        String name = etName.getText().toString();
        String score1 = etScore1.getText().toString();
        String name1 = etName1.getText().toString();
        String name2 = etName2.getText().toString();
        String score2 = etScore2.getText().toString();
        //判断数据是否填写
        if (TextUtils.isEmpty(name)) {
            etName.requestFocus();
            GlobalFunction.showToast("请输入比赛名称");
            return;
        }
        if (TextUtils.isEmpty(name1)) {
            GlobalFunction.showToast("请输入队伍1");
            return;
        }
        if (TextUtils.isEmpty(name2)) {
            GlobalFunction.showToast("请输入队伍2");
            return;
        }
        if (TextUtils.isEmpty(score1)) {
            GlobalFunction.showToast("请输入队伍1得分");
            return;
        }
        if (TextUtils.isEmpty(score2)) {
            GlobalFunction.showToast("请输入队伍2得分");
            return;
        }
        loadingDialog = new LoadingDialog(this);
        loadingDialog.setMessage("正在添加...");
        loadingDialog.show();
        Match mat = new Match();
        mat.setName(name);
        mat.setName1(name1);
        mat.setName2(name2);
        int sco1 = Integer.parseInt(score1);
        int sco2 = Integer.parseInt(score2);
        mat.setScore1(sco1);
        mat.setScore2(sco2);
        mat.setId((int)System.currentTimeMillis());
        mat.setCreateTime(System.currentTimeMillis());
        //保存数据到数据库
        BaseModelManager.getInstance().saveOrUpdateModel(this,Match.class, DBOpenHelper.class,mat);
        try {//休眠2秒
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        handler.sendEmptyMessage(0);

    }

}
