package com.baskt.ui;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.baskt.R;
import com.baskt.db.DBOpenHelper;
import com.baskt.model.Match;
import com.baskt.ui.base.ManageActivity;
import com.baskt.utils.GlobalFunction;
import com.baskt.utils.ScreenManager;
import com.hb.dialog.dialog.LoadingDialog;
import com.richard.tool.database.BaseModelManager;

import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

@ContentView(R.layout.activity_add_match_analysis)
public class AddMatchAnalysisActivity extends ManageActivity {
    @ViewInject(R.id.iv_back)
    public ImageView back;
    @ViewInject(R.id.et_dif)
    public EditText etDif;
    @ViewInject(R.id.et_com)
    public EditText etCom;
    @ViewInject(R.id.et_eff)
    public EditText etEff;
    @ViewInject(R.id.et_ratio)
    public EditText etRadio;
    @ViewInject(R.id.et_zhan)
    public EditText etZhan;
    @ViewInject(R.id.et_wrong)
    public EditText etWrong;
    @ViewInject(R.id.tv_ok)
    public TextView tvOk;
    private LoadingDialog loadingDialog;
    private Match match;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        x.view().inject(this);
        initView();
    }

    @Override
    protected void initView() {
        super.initView();
        match = (Match)getIntent().getSerializableExtra("item");
        tvOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                add();
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ScreenManager.getScreenManager().popActivity();
            }
        });
    }

    Handler handler = new Handler() {
        public void handleMessage(Message msg) {
            if (loadingDialog != null) {
                loadingDialog.dismiss();
            }
            switch (msg.what) {
                case 0:
                    GlobalFunction.showToast(AddMatchAnalysisActivity.this, "添加成功。");
                    ScreenManager.getScreenManager().popActivity();
                    break;
                case 1:
                    GlobalFunction.showToast(AddMatchAnalysisActivity.this, "添加失败");
                    break;
                default:
                    break;
            }
        }
    };

    private void add() {
        String dif = etDif.getText().toString();
        String com = etCom.getText().toString();
        String eff = etEff.getText().toString();
        String radio = etRadio.getText().toString();
        String zhan = etZhan.getText().toString();
        String wrong = etWrong.getText().toString();
        //判断数据是否填写
        if (TextUtils.isEmpty(dif)) {
            etDif.requestFocus();
            GlobalFunction.showToast("请输入球员技术难度");
            return;
        }
        if (TextUtils.isEmpty(com)) {
            GlobalFunction.showToast("请输入技术完成度");
            return;
        }
        if (TextUtils.isEmpty(eff)) {
            GlobalFunction.showToast("请输入技术有效性");
            return;
        }
        if (TextUtils.isEmpty(radio)) {
            GlobalFunction.showToast("请输入战术克制度");
            return;
        }
        if (TextUtils.isEmpty(zhan)) {
            GlobalFunction.showToast("请输入战术完成度");
            return;
        }
        if (TextUtils.isEmpty(wrong)) {
            GlobalFunction.showToast("请输入失误");
            return;
        }
        loadingDialog = new LoadingDialog(this);
        loadingDialog.setMessage("正在添加...");
        loadingDialog.show();

        int nDif = Integer.parseInt(dif);
        int nCom = Integer.parseInt(com);
        int nEff = Integer.parseInt(eff);
        int nRadio = Integer.parseInt(radio);
        int nZhan = Integer.parseInt(zhan);
        int nWrong = Integer.parseInt(wrong);
        match.setDifficulty(nDif);
        match.setCompletation(nCom);
        match.setEffect(nEff);
        match.setRatio(nRadio);
        match.setComp(nZhan);
        match.setWrong(nWrong);
        //保存数据到数据库
        BaseModelManager.getInstance().saveOrUpdateModel(this,Match.class, DBOpenHelper.class,match);
        try {//休眠2秒
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        handler.sendEmptyMessage(0);

    }

}
