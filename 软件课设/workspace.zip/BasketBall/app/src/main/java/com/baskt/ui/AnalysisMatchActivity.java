package com.baskt.ui;

import android.app.DatePickerDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.baskt.R;
import com.baskt.db.DBOpenHelper;
import com.baskt.model.Match;
import com.baskt.ui.base.ManageActivity;
import com.baskt.utils.GlobalFunction;
import com.baskt.utils.ScreenManager;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.formatter.IAxisValueFormatter;
import com.github.mikephil.charting.formatter.IValueFormatter;
import com.github.mikephil.charting.interfaces.datasets.IBarDataSet;
import com.github.mikephil.charting.utils.ViewPortHandler;
import com.hb.dialog.dialog.LoadingDialog;
import com.richard.tool.database.BaseModelManager;

import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

@ContentView(R.layout.activity_analysis_match)
public class AnalysisMatchActivity extends ManageActivity {
    @ViewInject(R.id.iv_back)
    public ImageView back;
    @ViewInject(R.id.et_team)
    public EditText etTeam;
    @ViewInject(R.id.et_start)
    public EditText etStart;
    @ViewInject(R.id.et_end)
    public EditText etEnd;
    @ViewInject(R.id.BarChart1)
    BarChart barChart1;
    @ViewInject(R.id.BarChart2)
    BarChart barChart2;
    @ViewInject(R.id.BarChart3)
    BarChart barChart3;
    @ViewInject(R.id.BarChart4)
    BarChart barChart4;
    @ViewInject(R.id.BarChart5)
    BarChart barChart5;
    @ViewInject(R.id.BarChart6)
    BarChart barChart6;
    @ViewInject(R.id.tv_ok)
    public TextView tvOk;
    private LoadingDialog loadingDialog;
    private int mYear;
    private int mMonth;
    private int mDay;
    private long startDate;
    private long endDate;
    private List<Integer> ls1 = new ArrayList<>();
    private List<Integer> ls2 = new ArrayList<>();
    private List<Integer> ls3 = new ArrayList<>();
    private List<Integer> ls4 = new ArrayList<>();
    private List<Integer> ls5 = new ArrayList<>();
    private List<Integer> ls6 = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        x.view().inject(this);
        initView();
    }

    @Override
    protected void initView() {
        super.initView();
        tvOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                add();
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ScreenManager.getScreenManager().popActivity();
            }
        });
        Calendar ca = Calendar.getInstance();
        mYear = ca.get(Calendar.YEAR);
        mMonth = ca.get(Calendar.MONTH);
        mDay = ca.get(Calendar.DAY_OF_MONTH);
        tvOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                search();
            }
        });
        etStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new DatePickerDialog(AnalysisMatchActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int year, int monthOfYear, int dayOfMonth) {
                        startDate = new Date(year, monthOfYear, dayOfMonth).getTime();
                        etStart.setText(year + "-" + (monthOfYear+1) + "-" + dayOfMonth);
                    }
                }, mYear, mMonth, mDay).show();
            }
        });
        etEnd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new DatePickerDialog(AnalysisMatchActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int year, int monthOfYear, int dayOfMonth) {
                        endDate = new Date(year, monthOfYear, dayOfMonth).getTime();
                        etEnd.setText(year + "-" + (monthOfYear+1) + "-" + dayOfMonth);
                    }
                }, mYear, mMonth, mDay).show();
            }
        });
    }
    //根据队伍名称和起始结束时间搜索比赛
    private void search() {
        ls1.clear();
        ls2.clear();
        ls3.clear();
        ls4.clear();
        ls5.clear();
        ls6.clear();
        String name = etTeam.getText().toString();
        String start = etStart.getText().toString();
        String end = etEnd.getText().toString();
        if (TextUtils.isEmpty(name)) {
            GlobalFunction.showToast("请输入球队名称");
            return;
        }
        if (TextUtils.isEmpty(start)) {
            GlobalFunction.showToast("请选择开始时间");
            return;
        }
        if (TextUtils.isEmpty(end)) {
            GlobalFunction.showToast("请选择结束时间");
            return;
        }
        List<Match> list1 = BaseModelManager.getInstance().getModelsByAttribute(this, Match.class, DBOpenHelper.class,
                "name1", name);
        List<Match> list2 = BaseModelManager.getInstance().getModelsByAttribute(this, Match.class, DBOpenHelper.class,
                "name2", name);
        List<Match> list = new ArrayList<>();
        list.addAll(list1);
        list.addAll(list2);
        if(list.size() == 0){
            GlobalFunction.showToast("未搜索到结果");
            return;
        }
        Collections.sort(list, new Comparator<Match>() {
            @Override
            public int compare(Match match, Match t1) {
                if (match.getCreateTime() < t1.getCreateTime()) {
                    return 1;
                } else if (match.getCreateTime() > t1.getCreateTime()) {
                    return -1;
                } else {
                    return 0;
                }
            }
        });
        for (Match item : list) {
            ls1.add(item.getDifficulty());
            ls2.add(item.getCompletation());
            ls3.add(item.getEffect());
            ls4.add(item.getRatio());
            ls5.add(item.getComp());
            ls6.add(item.getWrong());
        }
        //清除旧数据
        barChart1.clear();
        barChart2.clear();
        barChart3.clear();
        barChart4.clear();
        barChart5.clear();
        barChart6.clear();
        //绘制新图形
        initBarChart1();
        initBarChart2();
        initBarChart3();
        initBarChart4();
        initBarChart5();
        initBarChart6();
    }

    private void initBarChart1() {

        XAxis xAxis = barChart1.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);  // 设置x轴显示在下方，默认在上方
        xAxis.setDrawGridLines(false); // 将此设置为true，绘制该轴的网格线。
        xAxis.setLabelCount(5);  // 设置x轴上的标签个数
        xAxis.setTextSize(15f); // x轴上标签的大小
        final String labelName[] = {"一", "二", "三", "四", "五"};
        // 设置x轴显示的值的格式
        xAxis.setValueFormatter(new IAxisValueFormatter() {
            @Override
            public String getFormattedValue(float value, AxisBase axis) {
                if ((int) value < labelName.length) {
                    return labelName[(int) value];
                } else {
                    return "";
                }
            }
        });
        xAxis.setYOffset(15); // 设置标签对x轴的偏移量，垂直方向


        Legend legend = barChart1.getLegend();
        legend.setFormSize(12f); // 图例的图形大小
        legend.setTextSize(15f); // 图例的文字大小
        legend.setDrawInside(true); // 设置图例在图中
        legend.setOrientation(Legend.LegendOrientation.VERTICAL); // 图例的方向为垂直
        legend.setHorizontalAlignment(Legend.LegendHorizontalAlignment.RIGHT); //显示位置，水平右对齐
        legend.setVerticalAlignment(Legend.LegendVerticalAlignment.TOP); // 显示位置，垂直上对齐
        // 设置水平与垂直方向的偏移量
        legend.setYOffset(55f);
        legend.setXOffset(30f);


        // 设置y轴，y轴有两条，分别为左和右
        YAxis yAxis_right = barChart1.getAxisRight();
        yAxis_right.setAxisMaximum(1200f);  // 设置y轴的最大值
        yAxis_right.setAxisMinimum(0f);  // 设置y轴的最小值
        yAxis_right.setEnabled(false);  // 不显示右边的y轴

        YAxis yAxis_left = barChart1.getAxisLeft();
        yAxis_left.setAxisMaximum(1200f);
        yAxis_left.setAxisMinimum(0f);
        yAxis_left.setTextSize(15f); // 设置y轴的标签大小


        List<IBarDataSet> sets = new ArrayList<>();
        // 此处有两个DataSet，所以有两条柱子，BarEntry（）中的x和y分别表示显示的位置和高度
        // x是横坐标，表示位置，y是纵坐标，表示高度
        List<BarEntry> barEntries1 = new ArrayList<>();
        for(int i=0;i<ls1.size();i++){
            barEntries1.add(new BarEntry(i, ls1.get(i)));
        }

        BarDataSet barDataSet1 = new BarDataSet(barEntries1, "");
        barDataSet1.setValueTextColor(Color.RED); // 值的颜色
        barDataSet1.setValueTextSize(15f); // 值的大小
        barDataSet1.setColor(Color.parseColor("#1AE61A")); // 柱子的颜色
        barDataSet1.setLabel("球员技术难度"); // 设置标签之后，图例的内容默认会以设置的标签显示
        // 设置柱子上数据显示的格式
        barDataSet1.setValueFormatter(new IValueFormatter() {
            @Override
            public String getFormattedValue(float value, Entry entry, int dataSetIndex, ViewPortHandler viewPortHandler) {
                // 此处的value默认保存一位小数
                return value+"";
            }
        });

        sets.add(barDataSet1);

        BarData barData = new BarData(sets);
        barData.setBarWidth(0.3f); // 设置柱子的宽度
        barChart1.setData(barData);
    }

    private void initBarChart2() {
        XAxis xAxis = barChart2.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);  // 设置x轴显示在下方，默认在上方
        xAxis.setDrawGridLines(false); // 将此设置为true，绘制该轴的网格线。
        xAxis.setLabelCount(5);  // 设置x轴上的标签个数
        xAxis.setTextSize(15f); // x轴上标签的大小
        final String labelName[] = {"一", "二", "三", "四", "五"};
        // 设置x轴显示的值的格式
        xAxis.setValueFormatter(new IAxisValueFormatter() {
            @Override
            public String getFormattedValue(float value, AxisBase axis) {
                if ((int) value < labelName.length) {
                    return labelName[(int) value];
                } else {
                    return "";
                }
            }
        });
        xAxis.setYOffset(15); // 设置标签对x轴的偏移量，垂直方向


        Legend legend = barChart2.getLegend();
        legend.setFormSize(12f); // 图例的图形大小
        legend.setTextSize(15f); // 图例的文字大小
        legend.setDrawInside(true); // 设置图例在图中
        legend.setOrientation(Legend.LegendOrientation.VERTICAL); // 图例的方向为垂直
        legend.setHorizontalAlignment(Legend.LegendHorizontalAlignment.RIGHT); //显示位置，水平右对齐
        legend.setVerticalAlignment(Legend.LegendVerticalAlignment.TOP); // 显示位置，垂直上对齐
        // 设置水平与垂直方向的偏移量
        legend.setYOffset(55f);
        legend.setXOffset(30f);


        // 设置y轴，y轴有两条，分别为左和右
        YAxis yAxis_right = barChart2.getAxisRight();
        yAxis_right.setAxisMaximum(1200f);  // 设置y轴的最大值
        yAxis_right.setAxisMinimum(0f);  // 设置y轴的最小值
        yAxis_right.setEnabled(false);  // 不显示右边的y轴

        YAxis yAxis_left = barChart2.getAxisLeft();
        yAxis_left.setAxisMaximum(1200f);
        yAxis_left.setAxisMinimum(0f);
        yAxis_left.setTextSize(15f); // 设置y轴的标签大小


        List<IBarDataSet> sets = new ArrayList<>();
        // 此处有两个DataSet，所以有两条柱子，BarEntry（）中的x和y分别表示显示的位置和高度
        // x是横坐标，表示位置，y是纵坐标，表示高度
        List<BarEntry> barEntries1 = new ArrayList<>();
        for(int i=0;i<ls2.size();i++){
            barEntries1.add(new BarEntry(i, ls2.get(i)));
        }

        BarDataSet barDataSet1 = new BarDataSet(barEntries1, "");
        barDataSet1.setValueTextColor(Color.RED); // 值的颜色
        barDataSet1.setValueTextSize(15f); // 值的大小
        barDataSet1.setColor(Color.parseColor("#1AE61A")); // 柱子的颜色
        barDataSet1.setLabel("技术完成度"); // 设置标签之后，图例的内容默认会以设置的标签显示
        // 设置柱子上数据显示的格式
        barDataSet1.setValueFormatter(new IValueFormatter() {
            @Override
            public String getFormattedValue(float value, Entry entry, int dataSetIndex, ViewPortHandler viewPortHandler) {
                // 此处的value默认保存一位小数
                return value+"";
            }
        });

        sets.add(barDataSet1);

        BarData barData = new BarData(sets);
        barData.setBarWidth(0.3f); // 设置柱子的宽度
        barChart2.setData(barData);
    }

    private void initBarChart3() {
        XAxis xAxis = barChart3.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);  // 设置x轴显示在下方，默认在上方
        xAxis.setDrawGridLines(false); // 将此设置为true，绘制该轴的网格线。
        xAxis.setLabelCount(5);  // 设置x轴上的标签个数
        xAxis.setTextSize(15f); // x轴上标签的大小
        final String labelName[] = {"一", "二", "三", "四", "五"};
        // 设置x轴显示的值的格式
        xAxis.setValueFormatter(new IAxisValueFormatter() {
            @Override
            public String getFormattedValue(float value, AxisBase axis) {
                if ((int) value < labelName.length) {
                    return labelName[(int) value];
                } else {
                    return "";
                }
            }
        });
        xAxis.setYOffset(15); // 设置标签对x轴的偏移量，垂直方向


        Legend legend = barChart3.getLegend();
        legend.setFormSize(12f); // 图例的图形大小
        legend.setTextSize(15f); // 图例的文字大小
        legend.setDrawInside(true); // 设置图例在图中
        legend.setOrientation(Legend.LegendOrientation.VERTICAL); // 图例的方向为垂直
        legend.setHorizontalAlignment(Legend.LegendHorizontalAlignment.RIGHT); //显示位置，水平右对齐
        legend.setVerticalAlignment(Legend.LegendVerticalAlignment.TOP); // 显示位置，垂直上对齐
        // 设置水平与垂直方向的偏移量
        legend.setYOffset(55f);
        legend.setXOffset(30f);


        // 设置y轴，y轴有两条，分别为左和右
        YAxis yAxis_right = barChart3.getAxisRight();
        yAxis_right.setAxisMaximum(1200f);  // 设置y轴的最大值
        yAxis_right.setAxisMinimum(0f);  // 设置y轴的最小值
        yAxis_right.setEnabled(false);  // 不显示右边的y轴

        YAxis yAxis_left = barChart3.getAxisLeft();
        yAxis_left.setAxisMaximum(1200f);
        yAxis_left.setAxisMinimum(0f);
        yAxis_left.setTextSize(15f); // 设置y轴的标签大小


        List<IBarDataSet> sets = new ArrayList<>();
        // 此处有两个DataSet，所以有两条柱子，BarEntry（）中的x和y分别表示显示的位置和高度
        // x是横坐标，表示位置，y是纵坐标，表示高度
        List<BarEntry> barEntries1 = new ArrayList<>();
        for(int i=0;i<ls3.size();i++){
            barEntries1.add(new BarEntry(i, ls3.get(i)));
        }

        BarDataSet barDataSet1 = new BarDataSet(barEntries1, "");
        barDataSet1.setValueTextColor(Color.RED); // 值的颜色
        barDataSet1.setValueTextSize(15f); // 值的大小
        barDataSet1.setColor(Color.parseColor("#1AE61A")); // 柱子的颜色
        barDataSet1.setLabel("技术有效性"); // 设置标签之后，图例的内容默认会以设置的标签显示
        // 设置柱子上数据显示的格式
        barDataSet1.setValueFormatter(new IValueFormatter() {
            @Override
            public String getFormattedValue(float value, Entry entry, int dataSetIndex, ViewPortHandler viewPortHandler) {
                // 此处的value默认保存一位小数
                return value+"";
            }
        });

        sets.add(barDataSet1);

        BarData barData = new BarData(sets);
        barData.setBarWidth(0.3f); // 设置柱子的宽度
        barChart3.setData(barData);
    }

    private void initBarChart4() {
        XAxis xAxis = barChart4.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);  // 设置x轴显示在下方，默认在上方
        xAxis.setDrawGridLines(false); // 将此设置为true，绘制该轴的网格线。
        xAxis.setLabelCount(5);  // 设置x轴上的标签个数
        xAxis.setTextSize(15f); // x轴上标签的大小
        final String labelName[] = {"一", "二", "三", "四", "五"};
        // 设置x轴显示的值的格式
        xAxis.setValueFormatter(new IAxisValueFormatter() {
            @Override
            public String getFormattedValue(float value, AxisBase axis) {
                if ((int) value < labelName.length) {
                    return labelName[(int) value];
                } else {
                    return "";
                }
            }
        });
        xAxis.setYOffset(15); // 设置标签对x轴的偏移量，垂直方向


        Legend legend = barChart4.getLegend();
        legend.setFormSize(12f); // 图例的图形大小
        legend.setTextSize(15f); // 图例的文字大小
        legend.setDrawInside(true); // 设置图例在图中
        legend.setOrientation(Legend.LegendOrientation.VERTICAL); // 图例的方向为垂直
        legend.setHorizontalAlignment(Legend.LegendHorizontalAlignment.RIGHT); //显示位置，水平右对齐
        legend.setVerticalAlignment(Legend.LegendVerticalAlignment.TOP); // 显示位置，垂直上对齐
        // 设置水平与垂直方向的偏移量
        legend.setYOffset(55f);
        legend.setXOffset(30f);


        // 设置y轴，y轴有两条，分别为左和右
        YAxis yAxis_right = barChart4.getAxisRight();
        yAxis_right.setAxisMaximum(1200f);  // 设置y轴的最大值
        yAxis_right.setAxisMinimum(0f);  // 设置y轴的最小值
        yAxis_right.setEnabled(false);  // 不显示右边的y轴

        YAxis yAxis_left = barChart4.getAxisLeft();
        yAxis_left.setAxisMaximum(1200f);
        yAxis_left.setAxisMinimum(0f);
        yAxis_left.setTextSize(15f); // 设置y轴的标签大小


        List<IBarDataSet> sets = new ArrayList<>();
        // 此处有两个DataSet，所以有两条柱子，BarEntry（）中的x和y分别表示显示的位置和高度
        // x是横坐标，表示位置，y是纵坐标，表示高度
        List<BarEntry> barEntries1 = new ArrayList<>();
        for(int i=0;i<ls4.size();i++){
            barEntries1.add(new BarEntry(i, ls4.get(i)));
        }

        BarDataSet barDataSet1 = new BarDataSet(barEntries1, "");
        barDataSet1.setValueTextColor(Color.RED); // 值的颜色
        barDataSet1.setValueTextSize(15f); // 值的大小
        barDataSet1.setColor(Color.parseColor("#1AE61A")); // 柱子的颜色
        barDataSet1.setLabel("战术克制度"); // 设置标签之后，图例的内容默认会以设置的标签显示
        // 设置柱子上数据显示的格式
        barDataSet1.setValueFormatter(new IValueFormatter() {
            @Override
            public String getFormattedValue(float value, Entry entry, int dataSetIndex, ViewPortHandler viewPortHandler) {
                // 此处的value默认保存一位小数
                return value+"";
            }
        });

        sets.add(barDataSet1);

        BarData barData = new BarData(sets);
        barData.setBarWidth(0.3f); // 设置柱子的宽度
        barChart4.setData(barData);
    }

    private void initBarChart5() {
        XAxis xAxis = barChart5.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);  // 设置x轴显示在下方，默认在上方
        xAxis.setDrawGridLines(false); // 将此设置为true，绘制该轴的网格线。
        xAxis.setLabelCount(5);  // 设置x轴上的标签个数
        xAxis.setTextSize(15f); // x轴上标签的大小
        final String labelName[] = {"一", "二", "三", "四", "五"};
        // 设置x轴显示的值的格式
        xAxis.setValueFormatter(new IAxisValueFormatter() {
            @Override
            public String getFormattedValue(float value, AxisBase axis) {
                if ((int) value < labelName.length) {
                    return labelName[(int) value];
                } else {
                    return "";
                }
            }
        });
        xAxis.setYOffset(15); // 设置标签对x轴的偏移量，垂直方向


        Legend legend = barChart5.getLegend();
        legend.setFormSize(12f); // 图例的图形大小
        legend.setTextSize(15f); // 图例的文字大小
        legend.setDrawInside(true); // 设置图例在图中
        legend.setOrientation(Legend.LegendOrientation.VERTICAL); // 图例的方向为垂直
        legend.setHorizontalAlignment(Legend.LegendHorizontalAlignment.RIGHT); //显示位置，水平右对齐
        legend.setVerticalAlignment(Legend.LegendVerticalAlignment.TOP); // 显示位置，垂直上对齐
        // 设置水平与垂直方向的偏移量
        legend.setYOffset(55f);
        legend.setXOffset(30f);


        // 设置y轴，y轴有两条，分别为左和右
        YAxis yAxis_right = barChart5.getAxisRight();
        yAxis_right.setAxisMaximum(1200f);  // 设置y轴的最大值
        yAxis_right.setAxisMinimum(0f);  // 设置y轴的最小值
        yAxis_right.setEnabled(false);  // 不显示右边的y轴

        YAxis yAxis_left = barChart5.getAxisLeft();
        yAxis_left.setAxisMaximum(1200f);
        yAxis_left.setAxisMinimum(0f);
        yAxis_left.setTextSize(15f); // 设置y轴的标签大小


        List<IBarDataSet> sets = new ArrayList<>();
        // 此处有两个DataSet，所以有两条柱子，BarEntry（）中的x和y分别表示显示的位置和高度
        // x是横坐标，表示位置，y是纵坐标，表示高度
        List<BarEntry> barEntries1 = new ArrayList<>();
        for(int i=0;i<ls5.size();i++){
            barEntries1.add(new BarEntry(i, ls5.get(i)));
        }

        BarDataSet barDataSet1 = new BarDataSet(barEntries1, "");
        barDataSet1.setValueTextColor(Color.RED); // 值的颜色
        barDataSet1.setValueTextSize(15f); // 值的大小
        barDataSet1.setColor(Color.parseColor("#1AE61A")); // 柱子的颜色
        barDataSet1.setLabel("战术完成度"); // 设置标签之后，图例的内容默认会以设置的标签显示
        // 设置柱子上数据显示的格式
        barDataSet1.setValueFormatter(new IValueFormatter() {
            @Override
            public String getFormattedValue(float value, Entry entry, int dataSetIndex, ViewPortHandler viewPortHandler) {
                // 此处的value默认保存一位小数
                return value+"";
            }
        });

        sets.add(barDataSet1);

        BarData barData = new BarData(sets);
        barData.setBarWidth(0.3f); // 设置柱子的宽度
        barChart5.setData(barData);
    }

    private void initBarChart6() {
        XAxis xAxis = barChart6.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);  // 设置x轴显示在下方，默认在上方
        xAxis.setDrawGridLines(false); // 将此设置为true，绘制该轴的网格线。
        xAxis.setLabelCount(5);  // 设置x轴上的标签个数
        xAxis.setTextSize(15f); // x轴上标签的大小
        final String labelName[] = {"一", "二", "三", "四", "五"};
        // 设置x轴显示的值的格式
        xAxis.setValueFormatter(new IAxisValueFormatter() {
            @Override
            public String getFormattedValue(float value, AxisBase axis) {
                if ((int) value < labelName.length) {
                    return labelName[(int) value];
                } else {
                    return "";
                }
            }
        });
        xAxis.setYOffset(15); // 设置标签对x轴的偏移量，垂直方向


        Legend legend = barChart6.getLegend();
        legend.setFormSize(12f); // 图例的图形大小
        legend.setTextSize(15f); // 图例的文字大小
        legend.setDrawInside(true); // 设置图例在图中
        legend.setOrientation(Legend.LegendOrientation.VERTICAL); // 图例的方向为垂直
        legend.setHorizontalAlignment(Legend.LegendHorizontalAlignment.RIGHT); //显示位置，水平右对齐
        legend.setVerticalAlignment(Legend.LegendVerticalAlignment.TOP); // 显示位置，垂直上对齐
        // 设置水平与垂直方向的偏移量
        legend.setYOffset(55f);
        legend.setXOffset(30f);


        // 设置y轴，y轴有两条，分别为左和右
        YAxis yAxis_right = barChart6.getAxisRight();
        yAxis_right.setAxisMaximum(1200f);  // 设置y轴的最大值
        yAxis_right.setAxisMinimum(0f);  // 设置y轴的最小值
        yAxis_right.setEnabled(false);  // 不显示右边的y轴

        YAxis yAxis_left = barChart6.getAxisLeft();
        yAxis_left.setAxisMaximum(1200f);
        yAxis_left.setAxisMinimum(0f);
        yAxis_left.setTextSize(15f); // 设置y轴的标签大小


        List<IBarDataSet> sets = new ArrayList<>();
        // 此处有两个DataSet，所以有两条柱子，BarEntry（）中的x和y分别表示显示的位置和高度
        // x是横坐标，表示位置，y是纵坐标，表示高度
        List<BarEntry> barEntries1 = new ArrayList<>();
        for(int i=0;i<ls6.size();i++){
            barEntries1.add(new BarEntry(i, ls6.get(i)));
        }

        BarDataSet barDataSet1 = new BarDataSet(barEntries1, "");
        barDataSet1.setValueTextColor(Color.RED); // 值的颜色
        barDataSet1.setValueTextSize(15f); // 值的大小
        barDataSet1.setColor(Color.parseColor("#1AE61A")); // 柱子的颜色
        barDataSet1.setLabel("失误"); // 设置标签之后，图例的内容默认会以设置的标签显示
        // 设置柱子上数据显示的格式
        barDataSet1.setValueFormatter(new IValueFormatter() {
            @Override
            public String getFormattedValue(float value, Entry entry, int dataSetIndex, ViewPortHandler viewPortHandler) {
                // 此处的value默认保存一位小数
                return value+"";
            }
        });

        sets.add(barDataSet1);

        BarData barData = new BarData(sets);
        barData.setBarWidth(0.3f); // 设置柱子的宽度
        barChart6.setData(barData);
    }

    Handler handler = new Handler() {
        public void handleMessage(Message msg) {
            if (loadingDialog != null) {
                loadingDialog.dismiss();
            }
            switch (msg.what) {
                case 0:
                    GlobalFunction.showToast(AnalysisMatchActivity.this, "添加成功。");
                    ScreenManager.getScreenManager().popActivity();
                    break;
                case 1:
                    GlobalFunction.showToast(AnalysisMatchActivity.this, "添加失败");
                    break;
                default:
                    break;
            }
        }
    };

    private void add() {
//        String name = etName.getText().toString();
//        String score1 = etScore1.getText().toString();
//        String name1 = etName1.getText().toString();
//        String name2 = etName2.getText().toString();
//        String score2 = etScore2.getText().toString();
//        if (TextUtils.isEmpty(name)) {
//            etName.requestFocus();
//            GlobalFunction.showToast("请输入比赛名称");
//            return;
//        }
//        if (TextUtils.isEmpty(name1)) {
//            GlobalFunction.showToast("请输入队伍1");
//            return;
//        }
//        if (TextUtils.isEmpty(name2)) {
//            GlobalFunction.showToast("请输入队伍2");
//            return;
//        }
//        if (TextUtils.isEmpty(score1)) {
//            GlobalFunction.showToast("请输入队伍1得分");
//            return;
//        }
//        if (TextUtils.isEmpty(score2)) {
//            GlobalFunction.showToast("请输入队伍2得分");
//            return;
//        }
//        loadingDialog = new LoadingDialog(this);
//        loadingDialog.setMessage("正在添加...");
//        loadingDialog.show();
//        Match mat = new Match();
//        mat.setName(name);
//        mat.setName1(name1);
//        mat.setName2(name2);
//        int sco1 = Integer.parseInt(score1);
//        int sco2 = Integer.parseInt(score2);
//        mat.setScore1(sco1);
//        mat.setScore2(sco2);
//        mat.setId((int)System.currentTimeMillis());
//        mat.setCreateTime(System.currentTimeMillis());
//        BaseModelManager.getInstance().saveOrUpdateModel(this,Match.class, DBOpenHelper.class,mat);
//        try {
//            Thread.sleep(2000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//        handler.sendEmptyMessage(0);

    }

}
