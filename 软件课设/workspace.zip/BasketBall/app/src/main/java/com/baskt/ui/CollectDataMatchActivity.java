package com.baskt.ui;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.baskt.R;
import com.baskt.db.DBOpenHelper;
import com.baskt.model.Match;
import com.baskt.model.Record;
import com.baskt.model.Tail;
import com.baskt.ui.base.ManageActivity;
import com.baskt.utils.GlobalFunction;
import com.baskt.utils.GlobalVariables;
import com.baskt.utils.ScreenManager;
import com.baskt.widgets.TailView;
import com.hb.dialog.dialog.LoadingDialog;
import com.richard.tool.database.BaseModelManager;

import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

@ContentView(R.layout.activity_collect_data)
public class CollectDataMatchActivity extends ManageActivity {
    @ViewInject(R.id.iv_back)
    public ImageView back;
    @ViewInject(R.id.et_x)
    public EditText etX;
    @ViewInject(R.id.et_y)
    public EditText etY;
    @ViewInject(R.id.et_mem)
    public EditText etName;
    @ViewInject(R.id.et_dis)
    public EditText etDis;
    @ViewInject(R.id.et_speed)
    public EditText etSpeed;
    @ViewInject(R.id.tailView)
    TailView tailView;
    @ViewInject(R.id.tv_ok)
    public TextView tvOk;
    @ViewInject(R.id.tv_add)
    public TextView tvAdd;
    private LoadingDialog loadingDialog;
    private Match match;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        x.view().inject(this);
        initView();
    }

    @Override
    protected void initView() {
        super.initView();
        //获取比赛数据
        match = (Match)getIntent().getSerializableExtra("item");
        tvOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                save();
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ScreenManager.getScreenManager().popActivity();
            }
        });
        tvOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                save();
            }
        });
        tvAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //判断数据都是否填写
                String sx = etX.getText().toString();
                String sy = etY.getText().toString();
                String name = etName.getText().toString();
                if(TextUtils.isEmpty(name)){
                    GlobalFunction.showToast("请输入运动员姓名");
                    return;
                }
                if(TextUtils.isEmpty(sx)){
                    GlobalFunction.showToast("请输入x坐标");
                    return;
                }
                if(TextUtils.isEmpty(sy)){
                    GlobalFunction.showToast("请输入y坐标");
                    return;
                }
                int x = Integer.parseInt(sx);
                int y = Integer.parseInt(sy);
                Tail tail = new Tail();
                tail.setName(name);
                tail.setX(x);
                tail.setY(y);
                tail.setCreateTime(System.currentTimeMillis());
                tail.setId((int)System.currentTimeMillis());
                tail.setMid(match.getId());
                //保存数据
                BaseModelManager.getInstance().saveOrUpdateModel(CollectDataMatchActivity.this,Tail.class,DBOpenHelper.class,
                        tail);
                GlobalVariables.list.add(tail);
                tailView.invalidate();//界面刷新
            }
        });
    }

    Handler handler = new Handler() {
        public void handleMessage(Message msg) {
            if (loadingDialog != null) {
                loadingDialog.dismiss();
            }
            switch (msg.what) {
                case 0:
                    GlobalFunction.showToast(CollectDataMatchActivity.this, "添加成功。");
                    ScreenManager.getScreenManager().popActivity();
                    break;
                case 1:
                    GlobalFunction.showToast(CollectDataMatchActivity.this, "添加失败");
                    break;
                default:
                    break;
            }
        }
    };
    //保存数据
    private void save() {
        String name = etName.getText().toString();
        String distance = etDis.getText().toString();
        String speed = etSpeed.getText().toString();
        //判断各种数据是否填写
        if (TextUtils.isEmpty(name)) {
            etName.requestFocus();
            GlobalFunction.showToast("请输入队员名称");
            return;
        }
        if (TextUtils.isEmpty(distance)) {
            GlobalFunction.showToast("请输入距离");
            return;
        }
        if (TextUtils.isEmpty(speed)) {
            GlobalFunction.showToast("请输入速度");
            return;
        }

        loadingDialog = new LoadingDialog(this);
        loadingDialog.setMessage("正在添加...");
        loadingDialog.show();
        Record mat = new Record();
        int dis = Integer.parseInt(distance);
        int sp = Integer.parseInt(speed);
        mat.setName(name);
        mat.setDistance(dis);
        mat.setSpeed(sp);
        mat.setMid(match.getId());
        mat.setId((int)System.currentTimeMillis());
        mat.setCreateTime(System.currentTimeMillis());
        //保存数据到数据库
        BaseModelManager.getInstance().saveOrUpdateModel(this,Record.class, DBOpenHelper.class,mat);
        try {
            //休眠2秒
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        handler.sendEmptyMessage(0);

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        //清除旧记录
        GlobalVariables.list.clear();
    }
}
