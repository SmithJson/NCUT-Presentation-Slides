package com.baskt.ui;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.hb.dialog.dialog.LoadingDialog;
import com.richard.tool.database.BaseModelManager;
import com.baskt.R;
import com.baskt.db.DBOpenHelper;
import com.baskt.model.Member;
import com.baskt.ui.base.ManageActivity;
import com.baskt.utils.GlobalFunction;
import com.baskt.utils.GlobalVariables;
import com.baskt.utils.ScreenManager;
import com.baskt.utils.SettingUtils;
import com.baskt.widgets.RoundCheckBox;
import com.shehuan.niv.NiceImageView;

import org.json.JSONException;
import org.json.JSONObject;
import org.xutils.common.Callback;
import org.xutils.http.RequestParams;
import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

import java.util.List;

@ContentView(R.layout.activity_login)
public class LoginActivity extends ManageActivity {
    @ViewInject(R.id.iv_eye)
    ImageView eye;
    @ViewInject(R.id.avatar)
    NiceImageView avatr;
    @ViewInject(R.id.et_code)
    public EditText etUser;
    @ViewInject(R.id.tv_record)
    TextView tvRecord;
    @ViewInject(R.id.tv_ok)
    public TextView tvOk;
    @ViewInject(R.id.tv_register)
    public TextView tvRegister;
    @ViewInject(R.id.et_pwd)
    public EditText etPwd;
    @ViewInject(R.id.cb_pwd)
    public RoundCheckBox rcb;
    private boolean show = false;
    private LoadingDialog loadingDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        x.view().inject(this);
        initView();
    }

    @Override
    protected void initView() {
        super.initView();
        tvOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                login();
            }
        });
        tvRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                register();
            }
        });
        eye.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (show) {  //当CheckBox被选中
                    etPwd.setTransformationMethod(HideReturnsTransformationMethod
                            .getInstance());  //密码以明文显示
                } else {
                    etPwd.setTransformationMethod(PasswordTransformationMethod
                            .getInstance());  //以密文显示，以.代替
                }
                show = !show;
            }
        });
    }
    //注册
    private void register() {
        Intent intent = new Intent(this, RegisterActivity.class);
        startActivity(intent);
    }
    //登录
    private void login() {
        if ("".equals(etUser.getText().toString()) || "".equals(etPwd.getText().toString()))   //判断 帐号和密码
        {
            GlobalFunction.showToast(LoginActivity.this, "登录错误, 帐号或者密码不能为空，\n请输入后再登录！");
        } else {
            xLogin(etUser.getText().toString(), etPwd.getText().toString());

        }
    }

    //登录判断函数
    private void xLogin(final String username, String pwd) {
        loadingDialog = new LoadingDialog(this);
        loadingDialog.setMessage("正在登录...");
        loadingDialog.show();

        List<Member> mems = BaseModelManager.getInstance().getModelsByAttribute(this,Member.class,DBOpenHelper.class,
                "mobile",username);
        if(mems == null ||mems.size() == 0){
            handler.sendEmptyMessage(1);
        }else{
            Member member = null;
            for(Member mem:mems){
                if(mem.getPwd().equals(pwd)){
                    member = mem;
                    break;
                }
            }
            //账号密码错误
            if(member == null){
                handler.sendEmptyMessage(1);
            }else{//账号密码正确
                BaseModelManager.currentUser = username;
                BaseModelManager.getInstance().saveOrUpdateModel(LoginActivity.this, Member.class, DBOpenHelper.class, member);
                SettingUtils.setPreferencesString(LoginActivity.this, SettingUtils.AVATAR, member.getAvatar());
                SettingUtils.setPreferencesString(LoginActivity.this, SettingUtils.ACCOUNT, username);
                SettingUtils.setPreferencesString(LoginActivity.this, SettingUtils.NAME, member.getName());
                SettingUtils.setPreferencesInt(LoginActivity.this, SettingUtils.UID, member.getId());
                handler.sendEmptyMessage(0);
            }
        }
    }

    private void SaveUserInfo() {
        SettingUtils.setPreferencesString(this, SettingUtils.ACCOUNT, etUser.getText().toString());
        SettingUtils.setPreferencesString(this, SettingUtils.PASSWORD, etPwd.getText().toString());
        SettingUtils.setPreferencesBoolean(this, SettingUtils.IS_LOGIN, true);
    }

    Handler handler = new Handler() {
        public void handleMessage(Message msg) {
            if (loadingDialog != null) {
                loadingDialog.dismiss();
            }
            switch (msg.what) {
                case 0:
                    GlobalFunction.showToast("登录成功");
                    SaveUserInfo();
                    Intent intent = new Intent();
                    intent.setClass(LoginActivity.this, MainActivity.class);
                    startActivity(intent);
                    ScreenManager.getScreenManager().popActivity();
                    break;
                case 1:
                    GlobalFunction.showToast("登录失败，请稍后再试");
                    break;
                default:
                    break;
            }
        }

    };

}
