package com.baskt.ui;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.baskt.R;
import com.baskt.adapter.MatchAdapter;
import com.baskt.db.DBOpenHelper;
import com.baskt.model.Match;
import com.baskt.ui.base.ManageFragmentActivity;
import com.baskt.utils.DividerItemDecoration;
import com.baskt.utils.GlobalFunction;
import com.baskt.utils.ScreenManager;
import com.baskt.utils.SettingUtils;
import com.baskt.widgets.MenuItem;
import com.baskt.widgets.PopupMenu;
import com.bumptech.glide.Glide;
import com.cjj.MaterialRefreshLayout;
import com.cjj.MaterialRefreshListener;
import com.richard.tool.database.BaseModelManager;

import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

@ContentView(R.layout.activity_main)
public class MainActivity extends ManageFragmentActivity implements View.OnClickListener {
    @ViewInject(R.id.root)
    LinearLayout root;
    @ViewInject(R.id.iv_add)
    ImageView add;
    @ViewInject(R.id.title)
    TextView title;
    @ViewInject(R.id.recycler_view)
    RecyclerView mRecyclerView;
    @ViewInject(R.id.refresh_layout)
    MaterialRefreshLayout materialRefreshLayout;
    private MatchAdapter adapter;
    private List<Match> datas = new ArrayList<>();
    private int page = 1;
    private int rows = 10;
    private long exitTime;
    private PopupMenu menu;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        x.view().inject(this);
        initView();
    }

    protected void initView() {
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPop();
            }
        });
        materialRefreshLayout.setLoadMore(false);
        materialRefreshLayout.setMaterialRefreshListener(new MaterialRefreshListener() {
            @Override
            public void onRefresh(final MaterialRefreshLayout materialRefreshLayout) {
                //handler.sendEmptyMessage(1);
                materialRefreshLayout.finishRefreshLoadMore();
                materialRefreshLayout.finishRefresh();
            }

            @Override
            public void onRefreshLoadMore(final MaterialRefreshLayout materialRefreshLayout) {
                super.onRefreshLoadMore(materialRefreshLayout);
                materialRefreshLayout.finishRefreshLoadMore();
                materialRefreshLayout.finishRefresh();
            }
        });
        if(adapter == null){
            adapter = new MatchAdapter(this, datas);
        }
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mRecyclerView.setAdapter(adapter);
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        //添加分割线
        mRecyclerView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL_LIST));
    }


    private void showListDialog() {
        final String[] items = { "背景1","背景2","背景3","背景4" };
        AlertDialog.Builder listDialog =
                new AlertDialog.Builder(MainActivity.this);
        listDialog.setTitle("切换背景");
        listDialog.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                int vid = 0;
                switch (which){
                    case 0:
                        vid = R.mipmap.bk_1;
                        break;
                    case 1:
                        vid = R.mipmap.bk_2;
                        break;
                    case 2:
                        vid = R.mipmap.bk_3;
                        break;
                    case 3:
                        vid = R.mipmap.bk_4;
                        break;
                }
                Drawable dw = getResources().getDrawable(vid);
                root.setBackground(dw);
            }
        });
        listDialog.show();
    }
    //显示下拉菜单
    private void showPop() {
        menu = new PopupMenu(this);
        menu.setHeaderTitle(getText(R.string.choose));
        // Set Listener
        menu.setOnItemSelectedListener(new PopupMenu.OnItemSelectedListener() {

            @Override
            public void onItemSelected(MenuItem item) {
                switch (item.getItemId()) {
                    case 0://选择背景
                        showListDialog();
                        break;
                    case 1://添加比赛
                        Intent intent1= new Intent(MainActivity.this,AddMatchActivity.class);
                        startActivity(intent1);
                        break;
                    case 2://数据分析
                        Intent intent2 = new Intent(MainActivity.this,AnalysisMatchActivity.class);
                        startActivity(intent2);
                        break;
                    default:
                        break;
                }
            }
        });
        // Add Menu (Android menu like style)
        MenuItem item = menu.add(0, "切换背景");
        item = menu.add(1, "添加比赛");
        item = menu.add(2, "数据分析");
        menu.show(add);
    }

    @Override
    protected void onResume() {
        super.onResume();
        //刷新数据
        if(adapter == null){
            adapter = new MatchAdapter(this, datas);
        }
        List<Match> mtchs = BaseModelManager.getInstance().getAllModels(this,Match.class, DBOpenHelper.class);
        Collections.sort(mtchs, new Comparator<Match>() {
            @Override
            public int compare(Match match, Match t1) {
                if(match.getCreateTime()<t1.getCreateTime()){
                    return 1;
                }else if(match.getCreateTime()>t1.getCreateTime()){
                    return -1;
                }else{
                    return 0;
                }
            }
        });
        datas.clear();
        datas.addAll(mtchs);
        adapter.notifyDataSetChanged();
    }


    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK
                && event.getAction() == KeyEvent.ACTION_DOWN) {
            if ((System.currentTimeMillis() - exitTime) > 2000) {
                //弹出提示，可以有多种方式
                GlobalFunction.showToast(getApplicationContext(), "再按一次退出程序");
                exitTime = System.currentTimeMillis();
            } else {
                ScreenManager.getScreenManager().popActivity();
            }
            return true;
        }

        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            default:
                break;
        }
    }

    Handler handler = new Handler() {
        public void handleMessage(android.os.Message msg) {
            switch (msg.what) {
                case 0:
                    break;
                case 1:
                    break;
                default:
                    break;
            }
        }
    };
}
