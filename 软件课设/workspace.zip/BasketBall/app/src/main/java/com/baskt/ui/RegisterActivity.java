package com.baskt.ui;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.baskt.db.DBOpenHelper;
import com.baskt.model.Member;
import com.bumptech.glide.Glide;
import com.hb.dialog.dialog.LoadingDialog;
import com.hb.dialog.myDialog.ActionSheetDialog;
import com.baskt.R;
import com.baskt.ui.base.ManageActivity;
import com.baskt.utils.GlobalFunction;
import com.baskt.utils.GlobalVariables;
import com.baskt.utils.ScreenManager;
import com.baskt.widgets.RoundCheckBox;
import com.richard.tool.database.BaseModelManager;
import com.shehuan.niv.NiceImageView;
import com.tangxiaolv.telegramgallery.GalleryActivity;
import com.tangxiaolv.telegramgallery.GalleryConfig;

import org.json.JSONException;
import org.json.JSONObject;
import org.xutils.common.Callback;
import org.xutils.common.util.KeyValue;
import org.xutils.http.RequestParams;
import org.xutils.http.body.MultipartBody;
import org.xutils.view.annotation.ContentView;
import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import top.zibin.luban.Luban;
import top.zibin.luban.OnCompressListener;

@ContentView(R.layout.activity_register)
public class RegisterActivity extends ManageActivity {
    @ViewInject(R.id.iv_back)
    public ImageView back;
    @ViewInject(R.id.et_account)
    public EditText etAccount;
    @ViewInject(R.id.et_nickname)
    public EditText etNickname;
    @ViewInject(R.id.et_pwd)
    public EditText etPwd;
    @ViewInject(R.id.et_conf_pwd)
    public EditText etConfPwd;
    @ViewInject(R.id.tv_get_code)
    TextView tvGetCode;
    @ViewInject(R.id.cb_pwd)
    public RoundCheckBox rcb;
    @ViewInject(R.id.tv_agree)
    public TextView tvAgree;
    @ViewInject(R.id.tv_ok)
    public TextView tvOk;
    @ViewInject(R.id.avatar)
    public NiceImageView avatar;
    @ViewInject(R.id.iv_eye)
    ImageView eye;
    @ViewInject(R.id.iv_eye1)
    ImageView eye1;
    private String strImagePath;
    private boolean show = false;
    private boolean show1 = false;
    private LoadingDialog loadingDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        x.view().inject(this);
        initView();

    }

    @Override
    protected void initView() {
        super.initView();
        tvOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                register();
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ScreenManager.getScreenManager().popActivity();
            }
        });
        avatar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPhotoDialog();
            }
        });
        eye.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (show) {  //当CheckBox被选中
                    etPwd.setTransformationMethod(HideReturnsTransformationMethod
                            .getInstance());  //密码以明文显示
                } else {
                    etPwd.setTransformationMethod(PasswordTransformationMethod
                            .getInstance());  //以密文显示，以.代替
                }
                show = !show;
            }
        });
        eye1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (show1) {  //当CheckBox被选中
                    etConfPwd.setTransformationMethod(HideReturnsTransformationMethod
                            .getInstance());  //密码以明文显示
                } else {
                    etConfPwd.setTransformationMethod(PasswordTransformationMethod
                            .getInstance());  //以密文显示，以.代替
                }
                show1 = !show1;
            }
        });
    }

    /**
     * 取消倒计时
     *
     * @param v
     */
    public void oncancel(View v) {
        timer.cancel();
    }

    /**
     * 开始倒计时
     *
     * @param v
     */
    public void restart(View v) {
        timer.start();
    }

    private CountDownTimer timer = new CountDownTimer(60000, 1000) {

        @Override
        public void onTick(long millisUntilFinished) {
            tvGetCode.setText((millisUntilFinished / 1000) + "秒后可重发");
        }

        @Override
        public void onFinish() {
            tvGetCode.setEnabled(true);
            tvGetCode.setText("获取验证码");
        }
    };


    public void showToast(int strId) {
        String content = getText(strId).toString();
        GlobalFunction.showToast(this, content);
    }

    Handler handler = new Handler() {
        public void handleMessage(Message msg) {
            if (loadingDialog != null) {
                loadingDialog.dismiss();
            }
            switch (msg.what) {
                case 0:
                    GlobalFunction.showToast(RegisterActivity.this, "注册成功，请登录。");
                    ScreenManager.getScreenManager().popActivity();
                    break;
                case 1:
                    GlobalFunction.showToast(RegisterActivity.this, "注册用户失败");
                    break;
                default:
                    break;
            }
        }
    };
    //注册
    private void register() {
        if(TextUtils.isEmpty(strImagePath)){
            GlobalFunction.showToast("请设置头像");
            return;
        }
        //判断所需字段是否填写
        String strUsername = etAccount.getText().toString();
        String nickname = etNickname.getText().toString();
        String pwd = etPwd.getText().toString();
        String confPwd = etConfPwd.getText().toString();
        if (TextUtils.isEmpty(strUsername)) {
            etAccount.requestFocus();
            showToast(R.string.username_is_empty);
            return;
        }
        if (TextUtils.isEmpty(pwd)) {
            etPwd.requestFocus();
            showToast(R.string.password_is_empty);
            return;
        }
        if(TextUtils.isEmpty(nickname)){
            etNickname.requestFocus();
            GlobalFunction.showToast(this,"请输入昵称");
            return;
        }
        if (!GlobalFunction.veriyMobile(strUsername)) {
            etAccount.requestFocus();
            etAccount.selectAll();
            showToast(R.string.mobile_is_invalidate);
            return;
        }
        if (pwd.length() < 6 || pwd.length() > 20) {
            etPwd.requestFocus();
            etPwd.selectAll();
            showToast(R.string.password_is_invalidate);
            return;
        }
        if (!pwd.matches("[a-zA-Z0-9]+")) {
            etPwd.requestFocus();
            etPwd.selectAll();
            GlobalFunction.showToast(this, "密码由英文字母和数字混合组成");
            return;
        }
        if(!TextUtils.equals(pwd,confPwd)){
            GlobalFunction.showToast(this,"两次输入的密码不一致");
            return;
        }
        loadingDialog = new LoadingDialog(this);
        loadingDialog.setMessage("正在注册...");
        loadingDialog.show();
        //保存数据到数据库
        Member mem = new Member();
        mem.setAvatar(strImagePath);
        mem.setMobile(strUsername);
        mem.setName(nickname);
        mem.setPwd(pwd);
        mem.setId((int)System.currentTimeMillis());
        BaseModelManager.getInstance().saveOrUpdateModel(this,Member.class, DBOpenHelper.class,mem);
        try {
            //休眠2秒
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        handler.sendEmptyMessage(0);
    }


    /**
     * 拍照或者从相册选取文件
     */
    private void showPhotoDialog() {
        ActionSheetDialog dialog = new ActionSheetDialog(this).builder().setTitle("温馨提示")
                .addSheetItem("拍照", null, new ActionSheetDialog.OnSheetItemClickListener() {
                    @Override
                    public void onClick(int which) {
                        strImagePath = GlobalFunction.getFolder(GlobalVariables.TEMP, "") + System.currentTimeMillis()
                                + ".jpg";
                        if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
                            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                            File outFile = new File(strImagePath);
                            intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(outFile));
                            intent.putExtra(MediaStore.EXTRA_VIDEO_QUALITY, 1);
                            startActivityForResult(intent, GlobalVariables.TAKE_PICTURE);
                        } else {
                            GlobalFunction.showToast(RegisterActivity.this,
                                    getText(R.string.sdcrad_not_mount).toString());
                        }
                    }
                }).addSheetItem("从手机相册获取", null, new ActionSheetDialog.OnSheetItemClickListener() {
                    @Override
                    public void onClick(int which) {
                        GalleryConfig config = new GalleryConfig.Build()
                                .limitPickPhoto(1)
                                .singlePhoto(true)
                                .build();
                        GalleryActivity.openActivity(RegisterActivity.this,
                                GlobalVariables.PICK_PHOTO, config);
                    }
                });
        dialog.show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            // 如果是直接从相册获取
            case GlobalVariables.PICK_PHOTO:
                if (resultCode != RESULT_OK) {
                    break;
                }
                if (data != null) {
                    final List<String> result = (List<String>) data.getSerializableExtra(GalleryActivity.PHOTOS);
                    Luban.with(this)
                            .load(result)                                   // 传人要压缩的图片列表
                            .ignoreBy(100)                                  // 忽略不压缩图片的大小
                            .setTargetDir(GlobalFunction.getFolder(GlobalVariables.TEMP, ""))                        // 设置压缩后文件存储位置
                            .setCompressListener(new OnCompressListener() { //设置回调
                                @Override
                                public void onStart() {
                                    // TODO 压缩开始前调用，可以在方法内启动 loading UI
                                }

                                @Override
                                public void onSuccess(File file) {
                                    // TODO 压缩成功后调用，返回压缩后的图片文件
                                    strImagePath = file.getAbsolutePath();
                                    Glide.with(RegisterActivity.this).load(strImagePath).into(avatar);
                                }

                                @Override
                                public void onError(Throwable e) {
                                    // TODO 当压缩过程出现问题时调用
                                }
                            }).launch();    //启动压缩
                } else {
                    GlobalFunction.showToast(this, "获取图片失败" +
                            "");
                }
                break;
            // 如果是调用相机拍照时
            case GlobalVariables.TAKE_PICTURE:
                // Uri uri = data.getData();
                // String strImage = uri.getEncodedPath();
                if (resultCode != RESULT_OK) {
                    // GlobalFunction.showToast(this, R.string.get_picture_failed);
                    break;
                }
                File file = new File(strImagePath);
                if (file.exists()) {
                    Luban.with(this)
                            .load(file)                                   // 传人要压缩的图片列表
                            .ignoreBy(100)                                  // 忽略不压缩图片的大小
                            .setTargetDir(GlobalFunction.getFolder(GlobalVariables.TEMP, ""))                        // 设置压缩后文件存储位置
                            .setCompressListener(new OnCompressListener() { //设置回调
                                @Override
                                public void onStart() {
                                    // TODO 压缩开始前调用，可以在方法内启动 loading UI
                                }

                                @Override
                                public void onSuccess(File file) {
                                    // TODO 压缩成功后调用，返回压缩后的图片文件
                                    strImagePath = file.getAbsolutePath();
                                    Glide.with(RegisterActivity.this).load(strImagePath).into(avatar);
                                }

                                @Override
                                public void onError(Throwable e) {
                                    // TODO 当压缩过程出现问题时调用
                                }
                            }).launch();    //启动压缩
                } else {
                    GlobalFunction.showToast(this, "获取图片失败");
                }
                break;
            default:
                break;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }


}
