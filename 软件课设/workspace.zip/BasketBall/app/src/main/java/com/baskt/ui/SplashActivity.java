package com.baskt.ui;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.Window;
import android.view.WindowManager;

import com.baskt.R;
import com.baskt.ui.base.ManageActivity;
import com.baskt.utils.ScreenManager;
import com.baskt.utils.SettingUtils;
import com.richard.tool.database.BaseModelManager;

import org.xutils.view.annotation.ContentView;
import org.xutils.x;

@ContentView(R.layout.splash_activity)
public class SplashActivity extends ManageActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        x.view().inject(this);
        BaseModelManager.currentUser = "test";
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                //判断是否登录，登录则直接跳转到主页
                boolean isLogin = SettingUtils.getPreferencesBoolean(SplashActivity.this, SettingUtils.IS_LOGIN, false);
                if (isLogin) {
                    Intent intent = new Intent();
                    intent.setClass(SplashActivity.this, MainActivity.class);
                    startActivity(intent);
                    ScreenManager.getScreenManager().popActivity();
                } else {
                    //跳转到登录界面
                    Intent intent = new Intent(SplashActivity.this, LoginActivity.class);
                    startActivity(intent);
                    ScreenManager.getScreenManager().popActivity();
                }
            }
        }, 3000);
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }


}

