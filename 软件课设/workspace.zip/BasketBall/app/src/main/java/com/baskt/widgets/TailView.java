package com.baskt.widgets;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.View;

import com.baskt.R;
import com.baskt.model.Tail;
import com.baskt.utils.GlobalVariables;

public class TailView extends View {
    private Context mContext;
    public TailView(Context context) {
        super(context);
        mContext = context;
    }

    /**
     * 在xml布局文件中使用时自动调用
     * @param context
     */
    public TailView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        mContext = context;
    }


    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        Path mPath=new Path();
        Paint paint = new Paint();
        paint.setStrokeWidth(10);
        paint.setColor(Color.BLUE);
        paint.setAntiAlias(true);
        paint.setStyle(Paint.Style.STROKE);
        int w = this.getWidth();
        int h = this.getHeight();
        Bitmap bitmap = BitmapFactory.decodeResource(mContext.getResources(), R.mipmap.baskt);
        Rect src = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());
        Rect dst = new Rect(0, 0, w, h);
        //绘制背景图
        canvas.drawBitmap(bitmap,src,dst,paint);
        for (int i = 0; i < GlobalVariables.list.size(); i++) {
            Tail point = GlobalVariables.list.get(i);
            if(i==0){
                mPath.moveTo(point.getX(),point.getY());
            }else {
                mPath.lineTo(point.getX(),point.getY());
            }
        }
        //绘制运动轨迹
        canvas.drawPath(mPath,paint);

    }
}
