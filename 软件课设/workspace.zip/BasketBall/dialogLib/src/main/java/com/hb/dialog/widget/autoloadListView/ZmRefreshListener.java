package com.hb.dialog.widget.autoloadListView;

import android.support.v4.widget.SwipeRefreshLayout.OnRefreshListener;

public abstract class ZmRefreshListener implements OnRefreshListener, AutoLoadListView.OnLoadNextListener {

}
