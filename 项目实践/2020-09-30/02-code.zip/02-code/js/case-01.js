
// case-01.js
document.write("<hr>");
document.write("Hello World Wide Web");
document.write("<hr>");


