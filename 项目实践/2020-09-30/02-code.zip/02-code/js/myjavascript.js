
function displayMessage(firstName) {
    alert("Hello " + firstName );
}


    