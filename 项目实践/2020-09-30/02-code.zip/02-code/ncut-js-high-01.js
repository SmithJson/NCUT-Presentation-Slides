
var a = "hello";

var b = new String("hello");

console.log(typeof a);

console.log(typeof b);

if (a == b) {
    console.log("两个等号情况下，a等于b");
}

if (a === b) {
    console.log("三个等号情况下，a等于b");
}

