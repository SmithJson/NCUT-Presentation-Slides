

var a = function()  {  

};  

console.log(a);            // 将函数作为参数传递
