
var myFunction = function (a,b,c)  {   

};

console.log (myFunction.length) ;

