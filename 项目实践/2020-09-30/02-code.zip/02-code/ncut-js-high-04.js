
var a = 3;

(function () {
    var a = 5;

    console.log(a);               // 5 

})();

console.log(a);                //3