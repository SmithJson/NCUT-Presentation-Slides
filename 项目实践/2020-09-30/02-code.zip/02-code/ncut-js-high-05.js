
var a = 3;

function test() {
    var a = 5;
    console.log(a);
};

test();

console.log(a);

