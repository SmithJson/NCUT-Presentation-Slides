
function t1() {
    var a = 100;
    console.log("第一个 a 值是：", a);

    function t2() {
        var a = 200;
        console.log("第二个 a 值是：",a);
    }
    t2();
}

t1();

