
{
    var a = "block";
}

console.log(a);


