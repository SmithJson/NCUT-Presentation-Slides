
function hello() {
    var a = "function";
}
hello();
console.log(a);

