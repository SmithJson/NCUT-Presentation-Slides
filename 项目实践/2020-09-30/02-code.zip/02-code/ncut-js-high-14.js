
var funcs = [ ];
for (let i = 0; i < 5; i += 1) {
    let y = i;
    funcs.push(function () {
        console.log("y=",y);
    })
}

funcs.forEach(function (func) {
    func()
});

console.log("i=" , i); 


