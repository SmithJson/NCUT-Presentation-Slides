import Vue from 'vue'
import Router from 'vue-router'

import login from '@/components/login'
import manage from '@/views/manage'


Vue.use(Router)

export default new Router({
	routes: [
		{
			path: '/login',
			component: login
		},
		{
			path: '/',
			component: manage,
			children: [
				{
					path: '',
					component: manage,
				},
				// ...
			]
		},
	]
})
