<template>
  <div class="manage_page fillcontain">
    <el-row style="height: 100%;">
      <el-col :span="4" style="min-height: 100%; background-color: #2d3a4b;">
          <el-menu  style="min-height: 100%;" theme="dark" router>
          <el-menu-item index="manage">
            <i class="el-icon-menu"></i>首页
          </el-menu-item>
          
          <el-submenu index="2">
            <template slot="title">
              <i class="el-icon-plus"></i>用户管理
            </template>
            <el-menu-item index="users">用户列表</el-menu-item>
          </el-submenu>

          <el-submenu index="3">
            <template slot="title">
              <i class="el-icon-plus"></i>商品管理
            </template>
            <el-menu-item index="productList">商品列表</el-menu-item>
          </el-submenu>

          <el-submenu index="4">
            <template slot="title">
              <i class="el-icon-plus"></i>订单管理
            </template>
            <el-menu-item index="orderList">订单列表</el-menu-item>
          </el-submenu>
          <el-submenu index="5">
            <template slot="title">
              <i class="el-icon-setting"></i>设置
            </template>
            <el-menu-item index="adminSet">管理员设置</el-menu-item>
          </el-submenu>

        </el-menu>
      </el-col>
      <el-col :span="20" style="height: 100%;overflow: auto;">
        <keep-alive>
          <router-view></router-view>
        </keep-alive>
      </el-col>
    </el-row>
  </div>
</template>

<script>

export default {
  name: "manage",
  components: {},
 
   data() {
     return {
       //....
     }
   },

  created() {},
  mounted() {},
  computed: {
  },

  methods: {
    // ....
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
html,
body {
  margin: 0;
  padding: 0;
  width: 100%;
  height: 100%;
}
</style>
