import Vue from 'vue'
import Router from 'vue-router'

import login from '@/views/login'
import manage from '@/views/manage'
import order from '@/views/order'

Vue.use(Router)

export default new Router({
	routes: [
		{
			path: '/',
			component: login
		},
		{
			path: '/manage',
			component: manage,
			name: '',
			children: [
				{
					path: '',
					component: order,
				},
				{
					path: '/order',
					component: order,
				},
				// ...
			]
		},
	]
})
