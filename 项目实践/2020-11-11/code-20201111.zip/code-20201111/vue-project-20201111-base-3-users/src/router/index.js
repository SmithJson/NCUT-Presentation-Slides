import Vue from 'vue'
import Router from 'vue-router'

import login from '@/views/login'
import manage from '@/views/manage'
import order from '@/views/order'

const userList = r => require.ensure([], () => r(require('@/views/userList')), 'userList');



Vue.use(Router)

export default new Router({
	routes: [
		{
			path: '/',
			component: login
		},
		{
			path: '/manage',
			component: manage,
			name: '',
			children: [
				{
					path: '',
					component: userList,
				},
				{
					path: '/userList',
					component: userList,
				},
				{
					path: '/order',
					component: order,
				},
				// ...
			]
		},
	]
})
