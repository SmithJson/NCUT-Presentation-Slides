<template>
  <div class="container">
    <el-form
      ref="loginForm"
      :model="form"
      class="login-form"
      autocomplete="on"
      label-position="left"
    >
      <div class="title-container">
        <h3 class="title">电商管理系统</h3>
      </div>

      <el-form-item prop="username">
        <el-input
          ref="username"
          v-model="form.username"
          placeholder="请输入账号"
          name="username"
          type="text"
          tabindex="1"
          autocomplete="on"
        />
      </el-form-item>

      <el-form-item prop="password">
        <el-input
          :key="passwordType"
          ref="password"
          v-model="form.password"
          :type="passwordType"
          placeholder="请输入密码"
          name="password"
          tabindex="2"
          autocomplete="on"
          @blur="capsTooltip = false"
          @keyup.enter.native="handleLogin"
        />
      </el-form-item>

      <el-button type="primary" style="width:100%;margin-bottom:30px;" @click="handleLogin">登录</el-button>
    </el-form>
  </div>
</template>

<script>
import { Message } from "element-ui";
export default {
  name: "login",
  components: {},
  data() {
    return {
      form: {
        username: "",
        password: ""
      },
      passwordType: "password"
    };
  },

  created() {},
  mounted() {
    if (this.form.username === "") {
      this.$refs.username.focus();
    } else if (this.loginForm.password === "") {
      this.$refs.password.focus();
    }
  },

  methods: {
   handleLogin() {
      this.$http({
        method: "get",
        url: "http://localhost:3000/login"
        // params: {
        //   name: this.loginForm.username,
        //   pwd: this.loginForm.password
        // }
      })
        .then(res => {
          console.log("登录后返回的数据 =", res);
          if (
            res.data.username === this.form.username &&
            res.data.password === this.form.password
          ) {
            Message({
              message: "登录成功",
              type: "success",
              duration: 3 * 1000
            });
            this.$router.push("manage");
          } else {
            Message({
              message: "用户名或密码有误",
              type: "error",
              duration: 3 * 1000
            });
          }
        })
        .catch(error => {
          console.log(error);
        });
    }
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
html,
body {
  margin: 0;
  padding: 0;
  width: 100%;
  height: 100%;
}

.container {
  width: 100%;
  height: 100%;
  position: fixed;
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: #283443;
}

.title-container {
  position: relative;
}
.title-container .title {
  font-size: 26px;
  color: #fff;
  margin: 0px auto 40px auto;
  text-align: center;
  font-weight: bold;
}

.el-form {
  width: 400px;
  border: 1px solid #cccccc;
  border-radius: 4px;
  padding: 50px 50px 10px 50px;
}
</style>
