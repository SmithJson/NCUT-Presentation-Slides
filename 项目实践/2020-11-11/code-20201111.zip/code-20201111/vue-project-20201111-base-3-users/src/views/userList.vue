<template>
  <div >
    <el-button type="primary">新增用户</el-button>
    <div class="table_container">
      <el-table :data="tableData" highlight-current-row style="width: 100%">
        <el-table-column type="index" width="100"></el-table-column>
        <el-table-column property="register_time" label="注册日期" width="220"></el-table-column>
        <el-table-column property="username" label="用户姓名" width="220"></el-table-column>
        <el-table-column property="city" label="注册地址"></el-table-column>
        <el-table-column label="操作" width="160">
          <template slot-scope="scope">
            <el-button size="small" @click="handleEdit(scope.row)">编辑</el-button>
            <el-button size="small" type="danger" @click="handleDelete(scope.$index, scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      tableData: []
    };
  },
  components: {},
  created() {
    this.initData();
  },
  methods: {
    initData() {
      this.$http({
        method: "get",
        url: "http://localhost:3000/users"
      })
        .then(res => {
          console.log(" 用户列表 =", res);
          this.tableData = res.data;
          this.count = res.data.length;
        })
        .catch(error => {
          console.log(error);
        });
    }
  }
};
</script>

<style>
/* // @import "../style/mixin"; */
.table_container {
  padding: 20px;
}
</style>
