<template>
  <div >
    <el-button type="primary"  @click="addProduct()"  >添加商品</el-button>
    <div class="table_container">
      <el-table :data="tableData" highlight-current-row style="width: 100%">
        <el-table-column type="index" label="序号" width="100"></el-table-column>
     
      <el-table-column label="图片" align="center" height="10px">
        <template slot-scope="scope">
        <el-popover placement="right" title="" trigger="hover">
          <img :src="scope.row.image" />
          <img slot="reference" :src="scope.row.image" :alt="scope.row.image" style="max-height: 50px;max-width: 130px">
        </el-popover>
        </template>
      </el-table-column>
     
      <!-- <el-table-column property="image" label="商品图片" width="220"></el-table-column> -->
      <el-table-column property="name" label="商品名称" width="220"></el-table-column>
      <el-table-column property="price" label="商品价格" width="220"></el-table-column>
  
      <el-table-column property="detail" label="商品详情"></el-table-column>
      <el-table-column label="操作" width="160">
          <template slot-scope="scope">
            <el-button size="small" @click="editProduct(scope.$index, scope.row)">编辑</el-button>
            <el-button size="small" type="danger" @click="deleteProduct(scope.$index, scope.row)" >删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>

 <!-- 新增商品的弹框 -->
    <el-dialog title="新增商品" :visible.sync="addFormVisible">
      <el-form ref="addForm" :model="addForm" label-width="80px">
        <el-form-item  prop="image"  label="商品图片：" label-width="100px">
          <el-input v-model="addForm.image" ></el-input>
        </el-form-item>
        <el-form-item prop="name"  label="商品名称：" label-width="100px">
          <el-input v-model="addForm.name"  ></el-input>
        </el-form-item>

        <el-form-item prop="detail" label="商品描述：" label-width="100px">
          <el-input v-model="addForm.detail"  ></el-input>
        </el-form-item>

        <el-form-item prop="price" label="商品价格：" label-width="100px">
          <el-input v-model="addForm.price"  ></el-input>
        </el-form-item>
      </el-form>

      <div slot="footer" class="dialog-footer">
        <el-button @click="addFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="saveAdd()">确 定</el-button>
      </div>
    </el-dialog>

    <!-- 编辑商品的弹框 -->
    <el-dialog title="编辑商品" :visible.sync="editFormVisible">
      <el-form ref="editForm" :model="editForm" label-width="80px">
        <el-form-item  prop="image" label="商品图片：" label-width="100px">
          <el-input v-model="editForm.image" ></el-input>
        </el-form-item>
        <el-form-item prop="name" label="商品名称：" label-width="100px">
          <el-input v-model="editForm.name"></el-input>
        </el-form-item>

        <el-form-item prop="detail" label="商品描述：" label-width="100px">
          <el-input v-model="editForm.detail"></el-input>
        </el-form-item>

          <el-form-item prop="price" label="商品价格：" label-width="100px">
          <el-input v-model="editForm.price"></el-input>
        </el-form-item>
      </el-form>

      <div slot="footer" class="dialog-footer">
        <el-button @click="editFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="saveEdit()">确 定</el-button>
      </div>
    </el-dialog>

  </div>
</template>

<script>

import { Message } from "element-ui";

export default {
  data() {
    return {
      tableData: [],    // 用户列表数据
      
      addFormVisible: false, // 新增页面 （默认不显示）
      editFormVisible: false, // 编辑页面 （默认不显示）
      addForm: {
        image: "",
        name: "",
        detail: "",
        price: 0,
      },
      editForm: {
        id: "",
        image: "",
        name: "",
        detail: "",
        price: 0,
      },

      row_data: {} // 传给编辑组件的数据
    };
  },
  
  // 子组件引用
  components: {
  },

 
  created() {
    this.initData();
  },
  methods: {
    initData() {
      this.$http({
        method: "get",
        url: "http://localhost:3000/products"
      })
        .then(res => {
          console.log(" 商品列表 =", res.data);
          this.tableData = res.data;
        })
        .catch(error => {
          console.log(error);
        });
    },

    getUUID() {
      var s = [];
      var hexDigits = "0123456789abcdef";
      for (var i = 0; i < 36; i++) {
        s[i] = hexDigits.substr(Math.floor(Math.random() * 0x10), 1);
      }
      s[14] = "4";
      s[19] = hexDigits.substr((s[19] & 0x3) | 0x8, 1);
      s[8] = s[13] = s[18] = s[23] = "-";

      var uuid = s.join("");
      return uuid;
    },

    // 新增商品
    saveAdd() {
      console.log("保存新增商品");
      this.$http({
        method: "post",
        dataType: "json",
        url: "http://localhost:3000/products",
        data: {
          id: this.getUUID(),
          image: this.addForm.image,
          name: this.addForm.name,
          detail: this.addForm.detail,
          price: this.addForm.price,
        }
      })
        .then(res => {
          console.log("返回的数据 =", res);
          this.addFormVisible = false; // 关闭弹窗
          Message({
            message: "添加成功！",
            type: "success",
            duration: 1 * 1000
          });
          this.$refs.addForm.resetFields();  // 清除form缓存
          this.initData();  // 刷新表单
        })
        .catch(error => {
          console.log(error);
        });
    },

    //商品编辑
    saveEdit() {
      this.$http({
        method: "put",
        dataType: "json",
        url: "http://localhost:3000/products/" + this.editForm.id,
        data: {
          image: this.editForm.image,
          name: this.editForm.name,
          detail: this.editForm.detail,
          price: this.editForm.price,
        }
      })
        .then(res => {
          console.log("返回的数据 =", res);
          this.editFormVisible = false; // 关闭弹窗
          Message({
            message: "用户编辑成功！",
            type: "success",
            duration: 1 * 1000
          });
          this.$refs.editForm.resetFields();  // 清除form缓存
          this.initData();   // 刷新列表
        })
        .catch(error => {
          console.log(error);
        });
    },

    // 新增商品
    addProduct() {
      console.log("新增商品");
      this.addFormVisible = true;
    },

    // 编辑商品
    editProduct(index, row) {
      console.log("编辑商品 index=", index, "row=", row);
      this.editFormVisible = true;
      this.editForm.id = row.id;
      this.editForm.image = row.image;
      this.editForm.name = row.name;
      this.editForm.detail= row.detail;
      this.editForm.price= row.price;
    },

    // 删除商品
    deleteProduct(index, row) {
      console.log("删除操作");
      this.$confirm("将永久删除该商品, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      }).then(() => {
        this.$http({
          method: "delete",
          dataType: "json",
          url: "http://localhost:3000/products/" + row.id
        })
          .then(res => {
            console.log("返回的数据 =", res);
            this.$message({
              type: "success",
              message: "删除成功!"
            });
            this.initData();  // 刷新列表
          })
          .catch(error => {
            console.log(error);
          });
      });
    }
  }
};
</script>

<style>
.table_container {
  padding: 20px;
}
</style>
