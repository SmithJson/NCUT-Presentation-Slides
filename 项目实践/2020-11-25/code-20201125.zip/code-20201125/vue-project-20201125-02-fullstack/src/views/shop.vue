<template>
  <div >
  <el-row  :gutter="20" >
  <el-col :span="8"  v-for="(item,index) in productList"  :key="index" >
 
    <el-card :body-style="{ padding: '0px' }">
      <img :src="item.image" class="image">

        <div slot="header" style="line-height: 10px;" class="clearfix">
          <span>{{item.name}}</span>
        </div>
 
        <div  style="line-height: 30px;"  >{{item.detail}} </div>
        <div  class= "time"> 价格： ¥{{ item.price }}</div>
 
    </el-card>
  </el-col>
</el-row>


   </div>
</template>

<script>

// import { Message } from "element-ui";

export default {
  data() {
    return {
      productList: [],   // 商品列表     
   
    };
  },
  
  // 子组件引用
  components: {
  },

 
  created() {
    this.initData();
  },
  methods: {
    initData() {
      this.$http({
        method: "get",
        url: "http://localhost:3000/products"
      })
        .then(res => {
          console.log(" 商品列表 =", res.data);
          this.productList = res.data;
        })
        .catch(error => {
          console.log(error);
        });
    },

  }
};
</script>

<style>

.el-card {
    transition: all .5s;
  }
  .el-card:hover{
    margin-top: -5px;
  }
  

.time {
    font-size: 13px;
    color: #999;
  }
  
  .bottom {
    margin-top: 13px;
    line-height: 12px;
  }

  .right {
    padding: 0;
    float: right;
  }

  .image {
    width: 100%;
    display: block;
  }

  .clearfix:before,
  .clearfix:after {
      display: table;
      content: "";
  }
  
  .clearfix:after {
      clear: both
  }

</style>
