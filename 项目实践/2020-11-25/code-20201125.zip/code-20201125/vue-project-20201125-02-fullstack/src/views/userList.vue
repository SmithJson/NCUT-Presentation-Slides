<template>
  <div >
    <el-button type="primary"  @click="addUser()"  >新增用户</el-button>
    <div class="table_container">
      <el-table :data="tableData" highlight-current-row style="width: 100%">
        <el-table-column type="index" width="100"></el-table-column>
        <el-table-column property="created_date" label="注册日期" width="220"></el-table-column>
        <el-table-column property="user_name" label="用户姓名" width="220"></el-table-column>
        <el-table-column property="user_address" label="注册地址"></el-table-column>
        <el-table-column label="操作" width="160">
          <template slot-scope="scope">
            <el-button size="small" @click="editUser(scope.$index, scope.row)">编辑</el-button>
            <el-button size="small" type="danger" @click="deleteUser(scope.$index, scope.row)" >删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>

 <!-- 新增用户的弹框 -->
    <el-dialog title="新增用户" :visible.sync="addFormVisible">
      <el-form ref="addForm" :model="addForm" label-width="80px">
        <el-form-item  prop="user_name"  label="姓名："    label-width="100px">
          <el-input v-model="addForm.user_name" ></el-input>
        </el-form-item>
        <el-form-item prop="created_date"  label="注册日期：" label-width="100px">
          <el-input v-model="addForm.created_date"  ></el-input>
        </el-form-item>

        <el-form-item prop="user_address" label="注册地址：" label-width="100px">
          <el-input v-model="addForm.user_address"  ></el-input>
        </el-form-item>
      </el-form>

      <div slot="footer" class="dialog-footer">
        <el-button @click="addFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="saveAdd()">确 定</el-button>
      </div>
    </el-dialog>

    <!-- 编辑用户的弹框 -->
    <el-dialog title="编辑用户" :visible.sync="editFormVisible">
      <el-form ref="editForm" :model="editForm" label-width="80px">
        <el-form-item  prop="user_name" label="姓名：" label-width="100px">
          <el-input v-model="editForm.user_name" ></el-input>
        </el-form-item>
        <el-form-item prop="created_date" label="注册日期：" label-width="100px">
          <el-input v-model="editForm.created_date"></el-input>
        </el-form-item>

        <el-form-item prop="user_address" label="注册地址：" label-width="100px">
          <el-input v-model="editForm.user_address"></el-input>
        </el-form-item>
      </el-form>

      <div slot="footer" class="dialog-footer">
        <el-button @click="editFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="saveEdit()">确 定</el-button>
      </div>
    </el-dialog>

  </div>
</template>

<script>

import { Message } from "element-ui";

export default {
  data() {
    return {
      tableData: [],    // 用户列表数据
      
      addFormVisible: false, // 新增页面 （默认不显示）
      editFormVisible: false, // 编辑页面 （默认不显示）
      addForm: {
        user_name: "",
        created_date: "",
        user_address: ""
      },
      editForm: {
        id: "",
        user_name: "",
        created_date: "",
        user_address: ""
      },

      row_data: {} // 传给编辑组件的数据
    };
  },
  
  // 子组件引用
  components: {
  },

 
  created() {
    this.initData();
  },
  methods: {
    initData() {
      this.$http({
        method: "get",
        url: "http://localhost:3000/users"
      })
        .then(res => {
          console.log(" 用户列表 =", res.data);
          this.tableData = res.data;
        })
        .catch(error => {
          console.log(error);
        });
    },

    getUUID() {
      var s = [];
      var hexDigits = "0123456789abcdef";
      for (var i = 0; i < 36; i++) {
        s[i] = hexDigits.substr(Math.floor(Math.random() * 0x10), 1);
      }
      s[14] = "4";
      s[19] = hexDigits.substr((s[19] & 0x3) | 0x8, 1);
      s[8] = s[13] = s[18] = s[23] = "-";

      var uuid = s.join("");
      return uuid;
    },

    // 新增用户
    saveAdd() {
      console.log("保存新增用户");
      this.$http({
        method: "post",
        dataType: "json",
        url: "http://localhost:3000/users",
        data: {
          id: this.getUUID(),
          user_name: this.addForm.user_name,
          created_date: this.addForm.created_date,
          user_address: this.addForm.user_address
        }
      })
        .then(res => {
          console.log("返回的数据 =", res);
          this.addFormVisible = false; // 关闭弹窗
          Message({
            message: "添加成功！",
            type: "success",
            duration: 1 * 1000
          });
          this.$refs.addForm.resetFields();  // 清除form缓存
          this.initData();  // 刷新表单
        })
        .catch(error => {
          console.log(error);
        });
    },

    //用户编辑
    saveEdit() {
      this.$http({
        method: "put",
        dataType: "json",
        url: "http://localhost:3000/users/" + this.editForm.id,
        data: {
          user_name: this.editForm.user_name,
          created_date: this.editForm.created_date,
          user_address: this.editForm.user_address
        }
      })
        .then(res => {
          console.log("返回的数据 =", res);
          this.editFormVisible = false; // 关闭弹窗
          Message({
            message: "用户编辑成功！",
            type: "success",
            duration: 1 * 1000
          });
          this.$refs.editForm.resetFields();  // 清除form缓存
          this.initData();   // 刷新列表
        })
        .catch(error => {
          console.log(error);
        });
    },

    // 新增用户
    addUser() {
      console.log("新增用户");
      this.addFormVisible = true;
    },

    // 编辑用户
    editUser(index, row) {
      console.log("编辑用户 index=", index, "row=", row);
      this.editFormVisible = true;
      this.editForm.id = row.id;
      this.editForm.user_name = row.user_name;
      this.editForm.created_date = row.created_date;
      this.editForm.user_address = row.user_address;
    },

    // 删除用户
    deleteUser(index, row) {
      console.log("删除操作");
      this.$confirm("将永久删除该用户, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      }).then(() => {
        this.$http({
          method: "delete",
          dataType: "json",
          url: "http://localhost:3000/users/" + row.id
        })
          .then(res => {
            console.log("返回的数据 =", res);
            this.$message({
              type: "success",
              message: "删除成功!"
            });
            this.initData();  // 刷新列表
          })
          .catch(error => {
            console.log(error);
          });
      });
    }
  }
};
</script>

<style>
.table_container {
  padding: 20px;
}
</style>
