package com.ncut.demo.service;

import com.ncut.demo.bean.User;

import java.util.List;

public interface UserService {
    //增加一个User
    int insertUser(User user);
    //删除一个User
    int deleteByUserId(Integer id);
    //更改一个User
    int updateByUserId(User record);
    //查询一个User
    User selectByUserId(Integer id);
    //查询所有的Person
    List<User> selectAllUser();
}

