package com.ncut.demo.controller;

import com.ncut.demo.bean.User;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
public class UserController {

    @RequestMapping("/user")
    public List<User> query() {
        List<User> list = new ArrayList<>();

        User user = new User();
        user.setId(1L);
        user.setName("admin");
        user.setPassword("123456");
        list.add(user);

        User user1 = new User();
        user1.setId(2L);
        user1.setName("张三");
        user1.setPassword("123456");
        list.add(user1);

        return list;
    }
}
