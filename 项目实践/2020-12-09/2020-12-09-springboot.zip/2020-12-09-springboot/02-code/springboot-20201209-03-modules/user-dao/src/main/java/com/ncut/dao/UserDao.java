package com.ncut.dao;

import com.ncut.domain.User;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

// 为了被扫描到
@Component
public class UserDao {
    public List<User> query() {
        List<User> list = new ArrayList<>();
        User user = new User();
        user.setId(1L);
        user.setName("admin");
        user.setPassword("123456");
        list.add(user);
        return list;
    }

}



