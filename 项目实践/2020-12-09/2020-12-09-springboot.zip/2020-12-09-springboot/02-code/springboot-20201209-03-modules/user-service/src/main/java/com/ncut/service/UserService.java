package com.ncut.service;

import com.ncut.dao.UserDao;
import com.ncut.domain.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {
    @Autowired
    UserDao userDao;

    public List<User> query() {

        return userDao.query();
    }
}



